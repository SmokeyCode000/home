document.getElementById('submit').addEventListener('click', function () {
    const token = document.getElementById('token').value.trim();

    if (token) {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: loginToDiscord,
                args: [token]
            });
        });
    } else {
        alert('Please enter a valid Discord token.');
    }
});

function loginToDiscord(token) {
    localStorage.setItem('token', `"${token}"`);
    
    window.location.href = 'https://discord.com/channels/@me';
}
