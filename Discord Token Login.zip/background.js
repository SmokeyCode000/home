chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed and background worker is ready!');
});
